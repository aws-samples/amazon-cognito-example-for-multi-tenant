"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoDBForcedSignoutHandler = void 0;
const aws = require("aws-sdk");
class DynamoDBForcedSignoutHandler {
    constructor(tableName, docClient = new aws.DynamoDB.DocumentClient(), keyAttributeName = "username", lastForceSignOutTimeAttributeName = "lastForceSignOutTime", ttlAttributeName = "ttl", ttlInSeconds = 2592000 /*30 days*/) {
        this.tableName = tableName;
        this.docClient = docClient;
        this.keyAttributeName = keyAttributeName;
        this.lastForceSignOutTimeAttributeName = lastForceSignOutTimeAttributeName;
        this.ttlAttributeName = ttlAttributeName;
        this.ttlInSeconds = ttlInSeconds;
    }
    async isForcedSignOut(req) {
        const key = this.getKey(req.username);
        try {
            const params = {
                TableName: this.tableName,
                Key: key,
            };
            const result = await this.docClient.get(params).promise();
            if (result.Item && typeof result.Item[this.lastForceSignOutTimeAttributeName] === "number") {
                const issuedAtInMillis = req.claims.iat * 1000; // issued at is in seconds since epoch
                // if the token was issued before the last time this user issued a forced sign out, deny
                // (any newer sign-in will generate newer tokens hence will pass this check, but older ones will require re-auth
                if (issuedAtInMillis < result.Item[this.lastForceSignOutTimeAttributeName]) {
                    // optionally log the event
                    // console.warn("Login attempt with a token issued before a forced sign out:" + req.username, req.rawHeaders);
                    return true;
                }
            }
            return false;
        }
        catch (ex) {
            console.error("Error checking forced sign out", ex);
            throw ex;
        }
    }
    async forceSignOut(req) {
        const nowInMillis = Date.now();
        const item = this.getKey(req.username);
        item[this.ttlAttributeName] = Math.round(nowInMillis / 1000) + this.ttlInSeconds;
        item[this.lastForceSignOutTimeAttributeName] = nowInMillis;
        try {
            await this.docClient.put({
                TableName: this.tableName,
                Item: item,
            }).promise();
        }
        catch (ex) {
            console.error("Error revoking token: ", ex);
        }
    }
    getKey(username) {
        const key = {};
        key[this.keyAttributeName] = username;
        return key;
    }
}
exports.DynamoDBForcedSignoutHandler = DynamoDBForcedSignoutHandler;
