"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const expressApp_1 = require("./expressApp");
const port = 3001;
expressApp_1.expressApp.listen(port);
console.log(`Listening on port ${port}`);
