"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const aws_serverless_express_1 = require("aws-serverless-express");
const expressApp_1 = require("./expressApp");
const server = aws_serverless_express_1.createServer(expressApp_1.expressApp);
// noinspection JSUnusedGlobalSymbols
exports.handler = (event, context) => aws_serverless_express_1.proxy(server, event, context);
