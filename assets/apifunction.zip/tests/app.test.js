"use strict";
/* tslint:disable:trailing-comma only-arrow-functions object-literal-shorthand */
Object.defineProperty(exports, "__esModule", { value: true });
const dynamoDBStorageService_1 = require("../src/services/dynamoDBStorageService");
const aws_serverless_express_1 = require("aws-serverless-express");
const app_1 = require("../src/app");
const dynamoDBForcedSignoutHandler_1 = require("../src/services/dynamoDBForcedSignoutHandler");
const chai_1 = require("chai");
const pet_1 = require("../src/models/pet");
/**
 * An example integration test that can check authorization logic based on mock claims
 */
describe("integration test", async () => {
    const user1 = "user1";
    const user2 = "user2";
    const user1DisplayName = "User One";
    const user2DisplayName = "User Two";
    const itemsTableName = "Pets";
    const itemsTable = new Map();
    const usersTableName = "Users";
    const usersTable = new Map();
    const origin = "http://localhost:3000";
    const adminsGroupName = "pet-app-admins";
    const usersGroupName = "pet-app-users";
    let server;
    let handler;
    before(() => {
        server = aws_serverless_express_1.createServer(mockApp.expressApp);
        handler = (event, context) => aws_serverless_express_1.proxy(server, event, context, "PROMISE");
        itemsTable.set("p1", new pet_1.Pet("p1", "cat", 10, user1, user1DisplayName));
        itemsTable.set("p2", new pet_1.Pet("p2", "dog", 10, user2, user2DisplayName));
    });
    after(() => {
        server.close();
    });
    it("test get allowed paths with no auth", async () => {
        const response = await request("/", "GET");
        chai_1.expect(response.statusCode).to.equal(200);
    });
    it("test get all pets as admin", async () => {
        const response = await request("/pets", "GET", {
            username: user1,
            token_use: "access",
            "cognito:groups": [usersGroupName, adminsGroupName]
        });
        const pets = JSON.parse(response.body);
        chai_1.expect(pets).to.have.lengthOf(itemsTable.size);
    });
    it("test get only owned pets as user", async () => {
        const response = await request("/pets", "GET", {
            username: user1,
            token_use: "access",
            name: "User",
            family_name: "One",
            "cognito:groups": [usersGroupName]
        });
        const pets = JSON.parse(response.body);
        chai_1.expect(pets).to.have.lengthOf(1);
        chai_1.expect(pets[0]).to.eql(itemsTable.get("p1"));
    });
    it("test update other's pet not as owner - admin", async () => {
        const response = await request("/pets/p2", "PUT", {
            username: user1,
            token_use: "access",
            "cognito:groups": [usersGroupName, adminsGroupName]
        }, itemsTable.get("p2"));
        chai_1.expect(response.statusCode).to.equal(200);
    });
    it("test update other's pet not as owner - regular user", async () => {
        const response = await request("/pets/p2", "PUT", {
            username: user1,
            token_use: "access",
            "cognito:groups": [usersGroupName]
        }, itemsTable.get("p2"));
        chai_1.expect(response.statusCode).to.equal(403);
    });
    it("test no relevant groups", async () => {
        const response = await request("/pets", "GET", {
            username: user1,
            token_use: "access",
            "cognito:groups": ["other"]
        });
        chai_1.expect(response.statusCode).to.equal(403);
    });
    it("test no groups", async () => {
        const response = await request("/pets", "GET", {
            username: user1,
            token_use: "access",
            "cognito:groups": []
        });
        chai_1.expect(response.statusCode).to.equal(403);
    });
    it("test null groups", async () => {
        const response = await request("/pets", "GET", {
            username: user1,
            token_use: "access"
        });
        chai_1.expect(response.statusCode).to.equal(403);
    });
    it("test force sign out", async () => {
        const iat = (Date.now() / 1000) - 1;
        const claims = {
            username: user1,
            token_use: "access",
            "cognito:groups": [usersGroupName],
            iat: iat // token was issued a minute ago
        };
        // first request, should succeed
        const response0 = await request("/pets", "GET", claims);
        chai_1.expect(response0.statusCode).to.equal(200);
        // second, forceSignOut, should succeed
        const response1 = await request("/forceSignOut", "POST", claims);
        chai_1.expect(response1.statusCode).to.equal(200);
        // should fail because we are after forceSignOut and our token is "old"
        const response2 = await request("/pets", "GET", claims);
        chai_1.expect(response2.statusCode).to.equal(401);
        // should succeed because this is a different user
        const response3 = await request("/pets", "GET", { ...claims, username: user2 });
        chai_1.expect(response3.statusCode).to.equal(200);
        // FF to the future, user logged in again, got a new token, should succeed
        const response4 = await request("/pets", "GET", { ...claims, iat: (Date.now() / 1000) + 1 });
        chai_1.expect(response4.statusCode).to.equal(200);
    });
    const request = async (path, method, claims = {}, body) => {
        const tokenBase64 = Buffer.from(JSON.stringify(claims)).toString("base64");
        const eventAndContext = {
            "event": {
                "resource": "/{proxy+}",
                "path": path,
                "httpMethod": method,
                "headers": {
                    "Accept": "*/*",
                    "Content-Type": "application/json",
                    "Authorization": `header.${tokenBase64}.signature`,
                    "Host": "xyz.execute-api.xx-xxxx-x.amazonaws.com",
                    "origin": origin,
                    "Referer": origin + "/",
                    "User-Agent": "UserAgent"
                },
                "multiValueHeaders": {
                    "Accept": ["*/*"],
                    "Content-Type": ["application/json"],
                    "Authorization": [`header.${tokenBase64}.signature`],
                    "Host": ["xyz.execute-api.xx-xxxx-x.amazonaws.com"],
                    "origin": [origin],
                    "Referer": [origin + "/"],
                    "User-Agent": ["UserAgent"]
                },
                "queryStringParameters": null,
                "multiValueQueryStringParameters": null,
                "pathParameters": { "proxy": "pets" },
                "stageVariables": null,
                "requestContext": {
                    "resourcePath": "/{proxy+}",
                    "httpMethod": method,
                    "path": "/prod" + path,
                    "identity": {},
                    "domainName": "xyz.execute-api.xx-xxxx-x.amazonaws.com",
                    "apiId": "xyz"
                },
                "isBase64Encoded": false,
            },
            "context": {
                "callbackWaitsForEmptyEventLoop": true,
                getRemainingTimeInMillis() {
                    return 1000;
                },
                done(error, result) {
                    console.log("done", error, result);
                },
                fail(error) {
                    console.log("fail", error);
                },
                succeed(messageOrObject) {
                    console.log("succeed", messageOrObject);
                }
            }
        };
        if (body) {
            eventAndContext.event.body = JSON.stringify(body);
        }
        return handler(eventAndContext.event, eventAndContext.context).promise;
    };
    const mockApp = new app_1.App({
        cognito: {
            adminUserGlobalSignOut() {
                return {
                    promise() {
                        return Promise.resolve({});
                    }
                };
            }
        },
        adminsGroupName: adminsGroupName,
        usersGroupName: usersGroupName,
        authorizationHeaderName: "Authorization",
        userPoolId: "pool1",
        forceSignOutHandler: new dynamoDBForcedSignoutHandler_1.DynamoDBForcedSignoutHandler(usersTableName, {
            get(params) {
                return {
                    promise() {
                        const item = usersTable.get(params.Key.username);
                        return Promise.resolve(item ? { Item: item } : {});
                    }
                };
            },
            put(params) {
                return {
                    promise() {
                        const item = params.Item;
                        usersTable.set(item.username, item);
                        return Promise.resolve();
                    }
                };
            }
        }),
        storageService: new dynamoDBStorageService_1.DynamoDBStorageService(itemsTableName, {
            get(params) {
                return {
                    promise() {
                        const item = itemsTable.get(params.Key.id);
                        return Promise.resolve(item ? { Item: item } : {});
                    }
                };
            },
            put(params) {
                return {
                    promise() {
                        const item = params.Item;
                        itemsTable.set(item.id, item);
                        return Promise.resolve();
                    }
                };
            },
            scan(params) {
                return {
                    promise() {
                        const ret = {
                            Items: [...itemsTable.values()]
                        };
                        return Promise.resolve(ret);
                    }
                };
            }
        }),
        allowedOrigin: origin,
    });
});
