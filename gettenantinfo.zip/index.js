const AWS = require('aws-sdk');
AWS.config.update({ region: "us-east-1" });
const dynamo = new AWS.DynamoDB.DocumentClient();
let tableName = process.env.TABLE_NAME || "TenantInfo";
exports.handler = async (event, context) => {
    let domainName = event.queryStringParameters.email;
    domainName = domainName.split("@")[1];
    let idpID = "";
    const documentClient = new AWS.DynamoDB.DocumentClient({ region: "us-east-1" });
    console.log("tableName: " + tableName);
    const params = {
        TableName: tableName,
        Key: {
            emailDomain: domainName
        }
    };
    let data;
    try {
        data = await documentClient.get(params).promise();
        console.log(data);
        idpID = data.Item.idpID;
    }
    catch (err) {
        console.log(err);
    }
    const response = {
        statusCode: 200,
        headers: {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Credentials": true // Required for cookies, authorization headers with HTTPS
        },
        body: JSON.stringify(data),
    };
    return response;
};
